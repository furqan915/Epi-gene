uniq.gen <-
function(inputFiles,uniq, outputFiles) {system2("usearch.exe", args=c("-sortbysize", input= inputFiles,"-maxsize", input=uniq,"-fastaout", stdout=outputFiles))}
