Sortbylength <-
function(inputFiles,outputFiles) {system2("usearch.exe", args=c("-sortbylength", input= inputFiles, "-fastaout", stdout=outputFiles))}
