core.gen <-
function(inputFiles,organisms, outputFiles) {system2("usearch.exe", args=c("-sortbysize", input= inputFiles,"-minsize", input=organisms,"-fastaout", stdout=outputFiles))}
