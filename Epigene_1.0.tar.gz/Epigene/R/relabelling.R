relabelling <-
function(inputFiles,label,outputFiles) {system2("usearch.exe", args=c("-fastx_relabel", input= inputFiles, "-prefix", input=label, "-fastaout", stdout=outputFiles))}
