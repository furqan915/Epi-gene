Uniqgenes <-
function(y) {
  rownames(y) <- y$X
  bin3 <- y[ ,2: ncol(y)]
  bin4 <-as.data.frame(rowSums(bin3))
  colnames(bin4) <- "Totals"
  bin5 <- cbind.data.frame(bin3,bin4)
  bin6 <- subset(bin5, Totals <=1)
  bin6$Totals <-NULL
  bin7 <- as.data.frame(colSums(bin6))
  colnames(bin7) <- "Unique Genes"
  print(bin7)
}
