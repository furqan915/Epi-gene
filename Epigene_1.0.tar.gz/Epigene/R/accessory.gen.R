accessory.gen <-
function(inputFiles,organisms, outputFiles) {system2("usearch.exe", args=c("-sortbysize", input= inputFiles,"-maxsize", input=c(organisms-1),"-minsize 2", "-fastaout", stdout=outputFiles))}
