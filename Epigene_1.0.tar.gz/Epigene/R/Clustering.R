Clustering <-
function(inputFiles,id,outputFiles) {system2("usearch.exe", args=c("-cluster_smallmem", input= inputFiles,"-id",input=id, "-sizeout", "-centroids", stdout=outputFiles, "-uc", stdout="allclusters.txt"))}
