pan_matrix <-
function(clusters) {
  input <- subset(clusters, V1 %in% c("S","H"), select = c("V2", "V9"))###agyi samajh
  input[, 3] <- gsub('^org(.+)\\|.*', '\\1', input[, 2])
  possibleOrgs <- seq_len(max(input[, 3])) # = c(1, 2, 3, 4)
  pan.matrix <- vapply(unique(input[, 1]), function (x) possibleOrgs %in% input[input[, 1] == x, 3], logical(4))
  pan.matrix <- t(pan.matrix) * 1
  colnames (pan.matrix) <- paste0('org', possibleOrgs)
  rownames(pan.matrix) <- unique(input[, 1])
  bin_matrix <- write.csv(pan.matrix, "bin_matrix.csv")
  return(bin_matrix <- as.data.frame.matrix(pan.matrix))
}
